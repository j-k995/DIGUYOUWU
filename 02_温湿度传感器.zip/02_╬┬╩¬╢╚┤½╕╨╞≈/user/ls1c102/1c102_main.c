/*************************************************
 * 实验名称：温湿度传感器实验
 *
 * 实验准备：龙芯1C102开发板、温湿度传感器模块
 *
 * 实验接线：龙芯1C102开发板 ----   温湿度传感器模块
 *              P10        ----      P1
 *
 * 实验现象：OLED屏幕显示温湿度传感器信息
 **************************************************/
#include "ls1x.h"
#include "ls1x_gpio.h"
#include "UserGpio.h"
#include "Config.h"
#include "ls1x_clock.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "LED.h"
#include "KEY.h"
#include "BEEP.h"
#include "oled.h"
#include "oledpic.h"
#include "oled.h"
#include "dht11.h"

char str[30];
uint8_t key_value = 0;
uint8_t Zigbee_SendBuff[8];

int main(int arg, char *args[])
{
    OLED_Init();       // OLED初始化
    BEEP_Init();       // 蜂鸣器初始化
    LED_Init();        // LED初始化
    KEY_Init();        // 按键初始化
	OLED_Show_Str(10,0,"温湿度检测实验",16);
	OLED_Show_Str(16,3,"湿度:    %",16);
	OLED_Show_Str(16,6,"温度:    ℃",16);
    DHT11_Init();		// 温湿度传感器初始化

    while (1)
    {
        DHT11_Test();	// 读取温湿度信息

        Zigbee_SendBuff[0] = 0x55;
        Zigbee_SendBuff[1] = 0x01;
        Zigbee_SendBuff[2] = 0x02;
        Zigbee_SendBuff[3] = humidity;
        Zigbee_SendBuff[4] = temperature;
        Zigbee_SendBuff[5] = 0xbb;  

        UART_SendString(UART0,Zigbee_SendBuff,6);
    }
    return 0;
}
