/*************************************************
 * 实验名称：光强度传感器实验
 *
 * 实验准备：龙芯1C102开发板、光照度传感器模块
 *
 * 实验接线：龙芯1C102开发板 ----   光照度传感器模块
 *              P20        ----      P1
 *
 * 实验现象：OLED屏幕显示光照度信息
 **************************************************/
#include "ls1x.h"
#include "ls1x_gpio.h"
#include "UserGpio.h"
#include "Config.h"
#include "ls1x_clock.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "LED.h"
#include "KEY.h"
#include "BEEP.h"
#include "oled.h"
#include "oledpic.h"
#include "oled.h"
#include "bh1750.h"

char str[30];
uint8_t key_value = 0;
uint8_t License_Plate[12];
uint8_t Zigbee_SendBuff[8];
uint8_t flame_state = 0;
uint8_t PrintBuff[20];

int main(int arg, char *args[])
{
    OLED_Init();        // OLED初始化
    BEEP_Init();        // 蜂鸣器初始化
    LED_Init();         // LED初始化
    KEY_Init();         // 按键初始化
    OLED_Show_Str(0,1," FlameDetection",16);
    gpio_set_direction(GPIO_PIN_17, GPIO_Mode_In);

    while (1)
    {
        flame_state = gpio_get_pin(GPIO_PIN_17);

       	sprintf((char *)PrintBuff,"state:%d",flame_state);			//float转string
	    OLED_Show_Str(16*2,4,PrintBuff,16);
        
        Zigbee_SendBuff[0] = 0x55;
        Zigbee_SendBuff[1] = 0x01;
        Zigbee_SendBuff[2] = 0x04;
        Zigbee_SendBuff[3] = 0;
        Zigbee_SendBuff[4] = flame_state;
        Zigbee_SendBuff[5] = 0xbb;  

        UART_SendString(UART0,Zigbee_SendBuff,6);
    }
    return 0;
}
