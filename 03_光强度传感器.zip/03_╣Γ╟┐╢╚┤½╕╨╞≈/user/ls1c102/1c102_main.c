/*************************************************
 * 实验名称：光强度传感器实验
 *
 * 实验准备：龙芯1C102开发板、光照度传感器模块
 *
 * 实验接线：龙芯1C102开发板 ----   光照度传感器模块
 *              P20        ----      P1
 *
 * 实验现象：OLED屏幕显示光照度信息
 **************************************************/
#include "ls1x.h"
#include "ls1x_gpio.h"
#include "UserGpio.h"
#include "Config.h"
#include "ls1x_clock.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "LED.h"
#include "KEY.h"
#include "BEEP.h"
#include "oled.h"
#include "oledpic.h"
#include "oled.h"
#include "bh1750.h"

char str[30];
uint8_t key_value = 0;
uint8_t License_Plate[12];
uint8_t Zigbee_SendBuff[8];


int main(int arg, char *args[])
{
    OLED_Init();        // OLED初始化
    BEEP_Init();        // 蜂鸣器初始化
    LED_Init();         // LED初始化
    KEY_Init();         // 按键初始化
    OLED_Show_Str(26,1,"BH1750实验",16);
    BH1750_Init();	    // BH1750初始化

    while (1)
    {
        BH1750_Test();	// 读取光照度信息  
        
        Zigbee_SendBuff[0] = 0x55;
        Zigbee_SendBuff[1] = 0x01;
        Zigbee_SendBuff[2] = 0x03;
        Zigbee_SendBuff[3] = Lx_value / 256;
        Zigbee_SendBuff[4] = Lx_value % 256;
        Zigbee_SendBuff[5] = 0xbb;  

        UART_SendString(UART0,Zigbee_SendBuff,6);
    }
    return 0;
}
